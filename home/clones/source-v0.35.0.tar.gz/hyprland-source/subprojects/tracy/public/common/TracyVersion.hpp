#ifndef __TRACYVERSION_HPP__
#define __TRACYVERSION_HPP__

namespace tracy
{
namespace Version
{
enum { Major = 0 };
enum { Minor = 10 };
enum { Patch = 0 };
}
}

#endif
