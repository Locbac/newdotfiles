#ifndef __TRACYEVENTDEBUG_HPP__
#define __TRACYEVENTDEBUG_HPP__

namespace tracy
{
struct QueueItem;
void EventDebug( const QueueItem& ev );
}

#endif
